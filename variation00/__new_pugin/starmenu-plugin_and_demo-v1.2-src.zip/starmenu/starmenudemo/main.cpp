#include <QtGui/QApplication>
#include "qmlapplicationviewer.h"
#include "../src/starmenu.h"
#include "../src/staritem.h"


Q_DECL_EXPORT int main(int argc, char *argv[])
{
#ifndef MEEGO_EDITION_HARMATTAN
    QApplication::setGraphicsSystem("raster");
#endif
    QScopedPointer<QApplication> app(createApplication(argc, argv));
    QScopedPointer<QmlApplicationViewer> viewer(QmlApplicationViewer::create());

    qmlRegisterType<StarMenu>("StarMenu", 1, 0, "StarMenu");
    qmlRegisterType<StarItem>("StarMenu", 1, 0, "StarItem");

    viewer->setOrientation(QmlApplicationViewer::ScreenOrientationLockLandscape);//ScreenOrientationAuto);
//    viewer->setMainQmlFile("qml/starmenudemo/app.qml");
    viewer->setSource(QUrl("qrc:/qml/starmenudemo/app.qml"));

#ifdef Q_WS_MAEMO_5
    viewer->showMaximized();
    viewer->showFullScreen();
#else
    viewer->showExpanded();
#endif
    return app->exec();
}
